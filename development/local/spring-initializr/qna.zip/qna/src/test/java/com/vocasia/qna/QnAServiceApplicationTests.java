package com.vocasia.qna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QnAServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
